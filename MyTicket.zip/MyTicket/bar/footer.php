<footer class="app-footer"> <!--begin::To the end-->
            <div class="float-end d-none d-sm-inline">SMK Negeri 2 Malang</div> <!--end::To the end--> <!--begin::Copyright--> <strong>
            Hak Cipta &copy; <?php echo date('Y-m-d'); ?>&nbsp;
                <a href="https://smkn2malang.sch.id/" class="text-decoration-none">SMKN 2 Malang</a>.
            </strong>
            Dikembangkan oleh Tim ICT.
            <!--end::Copyright-->
</footer> <!--end::Footer-->